var next_x;
 var present_x;
 var present;
 var next;
 var direction;
 
function left_push()
{
	
	if(present<next)
	{
		next_x=canvas.width;
		present_x=screen_x;
		direction=-20;
	}
	else
	{
		next_x=0-screen_width;
		present_x=screen_x;
		direction=20;
	}
		
	screen_push=setInterval(move,20);

}
function move()
{


	if(present==next)
	{
		stop_anim();
	}
	else if(direction<0&&next_x<=screen_x)
	{
		present_x=next_x;
		next_x=canvas.width;
		present++;
	}
	else if(direction>0&&next_x>=screen_x)
	{
		present_x=next_x;
		next_x=0-screen_width;
		present--;
	}
	else
	{
	
		next_x+=direction;
		present_x+=direction;
		context.clearRect(0,screen_y,canvas.width,screen_height);
		draw_frame();		
	}
}
function stop_anim()
{

	clearInterval(screen_push);
}
