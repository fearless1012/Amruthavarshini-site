function getMousePos(evt){
	var rect = canvas.getBoundingClientRect(), root =document.documentElement;
	var mouseX = evt.clientX - rect.top - root.scrollTop;
	var mouseY = evt.clientY - rect.left - root.scrollLeft;
	return {
	  x: mouseX,
	  y: mouseY
	}
}
var setEventHandlers = function() {
		// Mouse
		window.addEventListener('mousemove', onMousemove, false);
		window.addEventListener('mousedown', onMousedown, false);
	}
	
function onMousemove(e) 
	{
		reset();
		var mousePos = getMousePos(e);
		
		for(var i=0;i<5;i++)
		if(mousePos.x>header_x[i]&&mousePos.x<(header_x[i]+header_width)&&mousePos.y>0&&mousePos.y<header_height)
		{
			if(!selected[i])
			selected[i]=2;
			break;
		}
		
		draw_header();
	}
function onMousedown(e) 
	{
		var mousePos = getMousePos(e);
		for(var i=0;i<5;i++)
		if(selected[i]==2)
		{
			
				for(var j=0;j<5;j++)
					if(selected[j]==1)
					{
						present=j;
						next=i;
						left_push();
						selected[j]=0;
						break;
					}
			selected[i]=1;
			break;
		}
		//draw_screen();
	}