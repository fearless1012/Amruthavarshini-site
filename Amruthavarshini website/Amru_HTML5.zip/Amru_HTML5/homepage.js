var canvas,context;
var screen_canvas,screen_context;
var size1,size2;
var header_icon;
var header_y,header_width,header_height;
var header_x;
var selected;
var screen_x,screen_y,screen_width,screen_height;
var screen_push;

window.onresize=resize;
window.onload=function()
	{
		canvas = document.getElementById("canvas");
		context = canvas.getContext("2d");
		
		init();
		resize();	
		
		// Start listening for events
		setEventHandlers();
	}
function init()
{
	header_icon = new Array(5);
	header_x= new Array(5);
    selected= new Array(5);
	
	selected[0]=1;
	for(var i=1;i<5;i++)
	selected[i]=0;
	
	header_icon[0] = new Image();
	header_icon[0].src = "home.png";
	header_icon[1] = new Image();
	header_icon[1].src = "contact.png";
	header_icon[2] = new Image();
	header_icon[2].src = "news.png";
	header_icon[3] = new Image();
	header_icon[3].src = "about.png";
	header_icon[4] = new Image();
	header_icon[4].src = "gallery.png";

}	
function resize()
	{
		size1=window.innerWidth;
		size2=window.innerHeight;
		
		canvas.width = size1;
		canvas.height = size2;
		
	 //positioning in header
	   header_y=0.5*size2/100;
	   header_width=10*size1/100;
	   header_height=10*size2/100;
	   for(var i=0;i<5;i++)
	   header_x[i]=(10+(i*17))*(size1/100);
	   
	//main information window size
	screen_x=10*size1/100;
	screen_y=15*size2/100;
	screen_width=80*size1/100;
	screen_height=75*size2/100;
	
		draw();
	}
	
function reset()
{
	for(var i=0;i<5;i++)
	if(selected[i]!=1)
	selected[i]=0;
}
 

	



