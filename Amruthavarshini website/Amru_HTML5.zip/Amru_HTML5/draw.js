function draw()
{
	context.clearRect(0,0,canvas.width,canvas.height);
	draw_header();
	//draw_screen();
}
function draw_header()
{
	context.clearRect(0,0,canvas.width,10*size2/100);
	   for(var i=0;i<5;i++)
		{
			if(selected[i]==1)
				context.globalAlpha = 0.5;
			if(selected[i])
			  {
				context.beginPath();
				context.rect(header_x[i],0,header_width,header_height);
				context.fillStyle = '#000000';
				context.fill();
			  }
	  context.drawImage(header_icon[i],header_x[i],header_y,header_width,header_height);
	  context.globalAlpha = 1;
	  }
}
function draw_frame()
{
	draw_screen(present_x);
	draw_content(present_x,present);
	draw_screen(next_x);
	if(direction<0)
	{
		draw_content(next_x,present+1);
	}
	else if(direction>0)
	{
		draw_content(next_x,present-1);
	}
	
}
function draw_screen(box_x)
{
	
	
	context.globalAlpha = 0.5;
	context.beginPath();
	context.rect(box_x,screen_y,screen_width,screen_height);
	context.fillStyle = '#000000';
	context.fill();
	context.globalAlpha = 1;
}
function draw_content(box_x,selected)
{
console.log(selected);
var fontSize=screen_height/20;
	//about selected
	if(selected==3)
	{
			
			var about_text='Amruthavarshini was created with the intent of raising awareness about Carnatic music within NIT, Trichy campus and bringing together all its Carnatic music enthusiasts. This is our humble endeavour tow	ards promoting this great art form and appreciating its subtleties and intricacies besides bringing forth the talents of the students of NIT, Trichy.'
			
			context.font =  fontSize + "px serif" ;
			context.textAlign = 'center';
			context.fillStyle = 'white';
			wrapText(about_text,box_x+screen_width/2,screen_y+screen_height/2, 3*screen_width/4,screen_height/10)
	}
}

function wrapText(text, x, y, maxWidth, lineHeight) {
        var words = text.split(' ');
        var line = '';

        for(var n = 0; n < words.length; n++) {
          var testLine = line + words[n] + ' ';
          var metrics = context.measureText(testLine);
          var testWidth = metrics.width;
          if (testWidth > maxWidth && n > 0) {
				if(y<screen_y||y>screen_height)
				{
					break;
					console.log("P");
				}
            context.fillText(line, x, y);
            line = words[n] + ' ';
            y += lineHeight;
          }
          else {
            line = testLine;
          }
        }
        context.fillText(line, x, y);
}